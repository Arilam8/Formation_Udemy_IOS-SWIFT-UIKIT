//
//  ViewController.swift
//  ApprendreLesAlertes
//
//  Created by matthieu passerel on 17/08/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var enterText: UIBarButtonItem!
    @IBOutlet weak var textLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func addButton(title: String, color: UIColor) -> UIAlertAction {
        return UIAlertAction(title: title, style: .default) { action in
            self.view.backgroundColor = color
        }
    }

    @IBAction func alertButtonPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Notre première alerte",
            message: "Félicitations vous avez montré votre première alerte",
            preferredStyle: .alert)
        let action = UIAlertAction(
            title: "OK",
            style: .default) { act in
                self.view.backgroundColor = .systemBackground
            }
        let second = UIAlertAction(title: "Cancel", style: .cancel) { act in
            self.view.backgroundColor = .cyan
        }
        let destr = UIAlertAction(title: "Destructive", style: .destructive, handler: nil)
        controller.addAction(action)
        controller.addAction(second)
        controller.addAction(destr)
        present(controller, animated: true, completion: nil)
        
    }
    
    @IBAction func textFieldButtonPressed(_ sender: UIBarButtonItem) {
        let tfController = UIAlertController(title: "Entrez du texte", message: nil, preferredStyle: .alert)
        tfController.addTextField { tf in
            tf.placeholder = "Entrez du texte ici"
        }
        tfController.addTextField { tf in
            tf.placeholder = "Second"
        }
        tfController.addAction(UIAlertAction(title: "Annuler", style: .destructive, handler: nil))
        let validateButton = UIAlertAction(title: "OK", style: .default) { action in
            if let value = tfController.textFields?.first?.text {
                self.textLabel.text = value
            }
            if let second = tfController.textFields?[1].text {
                print("J'ai quelque chose sur le second TF: \(second)")
            }
        }
        tfController.addAction(validateButton)
        present(tfController, animated: true, completion: nil)
    }
    
    @IBAction func actionSheetButtonPressed(_ sender: Any) {
        let actionSheetController = UIAlertController(
            title: "Modifiez le fond d'écran",
            message: "Choisissez votre couleur",
            preferredStyle: .actionSheet)
        
        let cancel = UIAlertAction(title: "Annuler", style: .cancel, handler: nil)
        actionSheetController.addAction(cancel)
        actionSheetController.addAction(addButton(title: "Rouge", color: .systemRed))
        actionSheetController.addAction(addButton(title: "Bleu", color: .systemBlue))
        actionSheetController.addAction(addButton(title: "Jaune", color: .systemYellow))
        actionSheetController.addAction(addButton(title: "Vert", color: .systemGreen))
        actionSheetController.addAction(addButton(title: "Menthe", color: .systemMint))
        
        let device = UIDevice.current.userInterfaceIdiom
        
        if device == .pad {
            if let popover = actionSheetController.popoverPresentationController {
                popover.sourceView = self.view
                let center = CGRect(
                    x: self.view.center.x,
                    y: self.view.center.y,
                    width: 0,
                    height: 0)
                popover.sourceRect = center
                popover.permittedArrowDirections = [.down, .left]
            }
        }
        
        
        present(actionSheetController, animated: true, completion: nil)
        
    }
    
}

